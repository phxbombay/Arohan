const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema({
    invoiceNumber: {
        type: String,
        required: true,
        unique: true
    },
    orderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Order',
        required: true
    },
    orderNumber: {
        type: String,
        required: true
    },
    customer: {
        name: {
            type: String,
            required: true
        },
        email: String,
        mobile: {
            type: String,
            required: true
        },
        address: {
            street: String,
            landmark: String,
            city: String,
            state: String,
            pincode: String
        }
    },
    items: [{
        productId: String,
        name: {
            type: String,
            required: true
        },
        quantity: {
            type: Number,
            required: true,
            min: 1
        },
        price: {
            type: Number,
            required: true
        },
        total: {
            type: Number,
            required: true
        }
    }],
    pricing: {
        subtotal: {
            type: Number,
            required: true
        },
        tax: {
            type: Number,
            default: 0
        },
        taxRate: {
            type: Number,
            default: 18 // 18% GST
        },
        shipping: {
            type: Number,
            default: 0
        },
        discount: {
            type: Number,
            default: 0
        },
        total: {
            type: Number,
            required: true
        }
    },
    paymentMethod: {
        type: String,
        enum: ['ONLINE', 'COD', 'UPI', 'Card', 'Wallet'],
        required: true
    },
    paymentStatus: {
        type: String,
        enum: ['PAID', 'PENDING', 'FAILED'],
        default: 'PENDING'
    },
    invoiceDate: {
        type: Date,
        default: Date.now
    },
    dueDate: {
        type: Date
    },
    status: {
        type: String,
        enum: ['DRAFT', 'ISSUED', 'PAID', 'CANCELLED'],
        default: 'ISSUED'
    },
    notes: String,
    pdfPath: String
}, {
    timestamps: true
});

// Index for faster queries
invoiceSchema.index({ invoiceNumber: 1 });
invoiceSchema.index({ orderId: 1 });
invoiceSchema.index({ 'customer.mobile': 1 });
invoiceSchema.index({ status: 1 });

// Generate invoice number before saving
invoiceSchema.pre('save', async function (next) {
    if (this.isNew && !this.invoiceNumber) {
        const year = new Date().getFullYear();
        const prefix = `INV-${year}-`;

        // Find the last invoice of this year
        const lastInvoice = await this.constructor
            .findOne({ invoiceNumber: new RegExp(`^${prefix}`) })
            .sort({ createdAt: -1 });

        let sequenceNumber = 1;
        if (lastInvoice) {
            const lastNumber = parseInt(lastInvoice.invoiceNumber.split('-')[2]);
            sequenceNumber = lastNumber + 1;
        }

        this.invoiceNumber = `${prefix}${String(sequenceNumber).padStart(4, '0')}`;
    }
    next();
});

module.exports = mongoose.model('Invoice', invoiceSchema);
