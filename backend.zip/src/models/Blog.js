const mongoose = require('mongoose');

const blogSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    slug: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    content: {
        type: String,
        required: true
    },
    excerpt: {
        type: String,
        maxlength: 300
    },
    featuredImage: {
        type: String,
        default: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800'
    },
    category: {
        type: String,
        required: true,
        enum: ['Healthcare', 'Technology', 'Product Updates', 'Research', 'Elder Care', 'Wellness'],
        default: 'Healthcare'
    },
    tags: [{
        type: String,
        trim: true
    }],
    author: {
        name: {
            type: String,
            default: 'Arohan Team'
        },
        email: String,
        avatar: String
    },
    status: {
        type: String,
        enum: ['draft', 'published', 'scheduled'],
        default: 'draft'
    },
    publishDate: {
        type: Date,
        default: Date.now
    },
    viewCount: {
        type: Number,
        default: 0
    },
    seo: {
        metaTitle: String,
        metaDescription: String,
        keywords: [String]
    },
    readTime: {
        type: Number, // in minutes
        default: 5
    },
    externalSource: {
        url: String, // Original article URL
        fetchedFrom: String, // RSS feed source
        fetchedAt: Date
    }
}, {
    timestamps: true
});

// Index for faster queries
blogSchema.index({ slug: 1 });
blogSchema.index({ status: 1, publishDate: -1 });
blogSchema.index({ category: 1 });
blogSchema.index({ tags: 1 });

// Generate slug from title before saving
blogSchema.pre('save', function (next) {
    if (this.isModified('title') && !this.slug) {
        this.slug = this.title
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/(^-|-$)/g, '');
    }
    next();
});

// Calculate read time from content (approx 200 words per minute)
blogSchema.pre('save', function (next) {
    if (this.isModified('content')) {
        const wordCount = this.content.split(/\s+/).length;
        this.readTime = Math.ceil(wordCount / 200);
    }
    next();
});

module.exports = mongoose.model('Blog', blogSchema);
