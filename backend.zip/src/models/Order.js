const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    orderId: {
        type: String,
        required: true,
        unique: true
    },
    amount: {
        type: Number,
        required: true,
        min: 1
    },
    currency: {
        type: String,
        default: 'INR'
    },
    paymentMethod: {
        type: String,
        enum: ['ONLINE', 'COD'],
        required: true
    },
    status: {
        type: String,
        enum: ['PENDING', 'PAID', 'COD_CONFIRMED', 'FAILED', 'CANCELLED'],
        default: 'PENDING'
    },
    customerDetails: {
        name: {
            type: String,
            required: true
        },
        email: String,
        mobile: {
            type: String,
            required: true
        },
        address: {
            street: {
                type: String,
                required: true
            },
            landmark: String,
            city: {
                type: String,
                required: true
            },
            state: {
                type: String,
                required: true
            },
            pincode: {
                type: String,
                required: true
            }
        }
    },
    items: [{
        productId: String,
        name: String,
        quantity: Number,
        price: Number
    }],
    razorpayOrderId: String,
    razorpayPaymentId: String,
    razorpaySignature: String,
    paidAt: Date,
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Index for faster queries
orderSchema.index({ orderId: 1 });
orderSchema.index({ 'customerDetails.mobile': 1 });
orderSchema.index({ status: 1 });

module.exports = mongoose.model('Order', orderSchema);
