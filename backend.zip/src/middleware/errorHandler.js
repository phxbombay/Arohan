import logger from '../config/logger.js';
import AppError from '../utils/AppError.js';

const errorHandler = (err, req, res, next) => {
    err.statusCode = err.statusCode || 500;
    err.status = err.status || 'error';

    // Log error
    if (err.statusCode === 500) {
        logger.error('Internal Server Error', {
            error: err.message,
            stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
            path: req.path,
            method: req.method,
            ip: req.ip,
            requestId: req.id
        });
    } else {
        logger.warn('Client Error', {
            error: err.message,
            statusCode: err.statusCode,
            path: req.path,
            method: req.method,
            ip: req.ip,
            requestId: req.id
        });
    }

    // Development error response (detailed)
    if (process.env.NODE_ENV === 'development') {
        return res.status(err.statusCode).json({
            status: err.status,
            error: err,
            message: err.message,
            stack: err.stack
        });
    }

    // Production error response (sanitized)
    // Operational, trusted error: send message to client
    if (err.isOperational) {
        return res.status(err.statusCode).json({
            status: err.status,
            message: err.message
        });
    }

    // Programming or unknown error: don't leak error details
    return res.status(500).json({
        status: 'error',
        message: 'Something went wrong. Please try again later.'
    });
};

export default errorHandler;
