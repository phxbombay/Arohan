const express = require('express');
const router = express.Router();
const razorpayController = require('../controllers/razorpayController');

/**
 * @route   POST /api/orders/create
 * @desc    Create order (Online or COD)
 * @access  Public
 * @body    { amount, currency, paymentMethod, customerDetails, items }
 */
router.post('/create', razorpayController.createOrder);

/**
 * @route   POST /api/orders/verify
 * @desc    Verify Razorpay payment signature
 * @access  Public
 * @body    { razorpay_order_id, razorpay_payment_id, razorpay_signature }
 */
router.post('/verify', razorpayController.verifyPayment);

/**
 * @route   GET /api/orders/:orderId
 * @desc    Get order status
 * @access  Public
 */
router.get('/:orderId', razorpayController.getOrderStatus);

/**
 * @route   POST /api/orders/create-qr
 * @desc    Create UPI QR Code for payment
 * @access  Public
 * @body   { amount, user_email }
 */
router.post('/create-qr', razorpayController.createQrCode);

/**
 * @route   GET /api/orders/check-qr/:qrId
 * @desc    Check QR Code payment status
 * @access  Public
 */
router.get('/check-qr/:qrId', razorpayController.checkQrStatus);

/**
 * @route   POST /api/orders/create-cod
 * @desc    Create Cash on Delivery Order
 * @access  Public
 */
router.post('/create-cod', razorpayController.createCodOrder);

/**
 * @route   POST /api/orders/webhook
 * @desc    Handle Razorpay webhooks
 * @access  Public (Razorpay servers)
 */
router.post('/webhook', razorpayController.handleWebhook);

module.exports = router;
