import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import pool from '../config/db.js';
import { generateAccessToken, generateRefreshToken } from '../utils/generateToken.js';

const setTokenCookie = (res, token) => {
    const cookieOptions = {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    };
    res.cookie('refreshToken', token, cookieOptions);
};

// @desc    Register a new user
// @route   POST /v1/auth/register
// @access  Public
export const registerUser = async (req, res) => {
    const { full_name, email, password } = req.body; // Role removed from here

    try {
        const userExists = await pool.query('SELECT * FROM users WHERE email = $1', [email]);

        if (userExists.rows.length > 0) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash(password, salt);

        // Explicitly set default role to patient
        const newUser = await pool.query(
            'INSERT INTO users (full_name, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING user_id, full_name, email, role',
            [full_name, email, passwordHash, 'patient']
        );

        const user = newUser.rows[0];

        // Generate Tokens
        const accessToken = generateAccessToken(user.user_id);
        const refreshToken = generateRefreshToken();

        // Hash refresh token for storage
        const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

        // Store refresh token
        await pool.query(
            'INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, NOW() + INTERVAL \'7 days\')',
            [user.user_id, refreshTokenHash]
        );

        setTokenCookie(res, refreshToken);

        res.status(201).json({
            user_id: user.user_id,
            full_name: user.full_name,
            email: user.email,
            role: user.role,
            accessToken: accessToken, // Frontend relies on this now
        });
    } catch (error) {
        console.error('Registration Error:', error.message, error.stack);
        res.status(500).json({ message: 'Server error: ' + error.message });
    }
};

// @desc    Auth user & get token
// @route   POST /v1/auth/login
// @access  Public
export const loginUser = async (req, res) => {
    const { email, password } = req.body;

    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        const user = result.rows[0];

        if (user && (await bcrypt.compare(password, user.password_hash))) {
            const accessToken = generateAccessToken(user.user_id);
            const refreshToken = generateRefreshToken();

            const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

            // Revoke old tokens? Or allow multiple devices? Let's allow multiple devices but limit count if needed.
            // For now, just insert.
            await pool.query(
                'INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, NOW() + INTERVAL \'7 days\')',
                [user.user_id, refreshTokenHash]
            );

            setTokenCookie(res, refreshToken);

            res.json({
                user_id: user.user_id,
                full_name: user.full_name,
                email: user.email,
                role: user.role,
                accessToken: accessToken,
            });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    } catch (error) {
        console.error('Login Error:', error.message, error.stack);
        res.status(500).json({ message: 'Server error: ' + error.message });
    }
};

// @desc    Refresh Access Token
// @route   POST /v1/auth/refresh-token
// @access  Public (via Cookie)
export const refreshToken = async (req, res) => {
    const refreshToken = req.cookies.refreshToken;

    if (!refreshToken) {
        return res.status(401).json({ message: 'Not authorized, no token' });
    }

    try {
        const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

        const tokenResult = await pool.query(
            'SELECT * FROM refresh_tokens WHERE token_hash = $1 AND expires_at > NOW() AND revoked_at IS NULL',
            [refreshTokenHash]
        );

        if (tokenResult.rows.length === 0) {
            // Potential reuse attack detection could go here (delete user's tokens if reuse detected)
            res.clearCookie('refreshToken');
            return res.status(403).json({ message: 'Token invalid or expired' });
        }

        const storedToken = tokenResult.rows[0];

        // Get user info
        const userResult = await pool.query('SELECT user_id, full_name, email, role FROM users WHERE user_id = $1', [storedToken.user_id]);
        if (userResult.rows.length === 0) return res.status(403).json({ message: 'User not found' });

        const user = userResult.rows[0];

        // Token Rotation: Revoke used token, issue new one
        await pool.query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE id = $1', [storedToken.id]);

        const newAccessToken = generateAccessToken(user.user_id);
        const newRefreshToken = generateRefreshToken();
        const newRefreshTokenHash = crypto.createHash('sha256').update(newRefreshToken).digest('hex');

        await pool.query(
            'INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, NOW() + INTERVAL \'7 days\')',
            [user.user_id, newRefreshTokenHash]
        );

        setTokenCookie(res, newRefreshToken);

        res.json({
            accessToken: newAccessToken
        });

    } catch (error) {
        console.error('Refresh Error:', error.message);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Logout user
// @route   POST /v1/auth/logout
// @access  Public
export const logoutUser = async (req, res) => {
    const refreshToken = req.cookies.refreshToken;

    if (refreshToken) {
        const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
        // Revoke token in DB
        await pool.query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_hash = $1', [refreshTokenHash]);
    }

    res.clearCookie('refreshToken');
    res.json({ message: 'Logged out successfully' });
};
