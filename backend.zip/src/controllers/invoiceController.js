const Invoice = require('../models/Invoice');
const Order = require('../models/Order');
const { generateInvoicePDF } = require('../services/pdfGenerator');
const path = require('path');
const fs = require('fs');

/**
 * Generate invoice from order
 * POST /api/invoices/generate/:orderId
 */
exports.generateInvoice = async (req, res) => {
    try {
        const { orderId } = req.params;

        // Check if invoice already exists
        const existingInvoice = await Invoice.findOne({ orderId });
        if (existingInvoice) {
            return res.status(400).json({
                success: false,
                message: 'Invoice already exists for this order',
                invoiceId: existingInvoice._id
            });
        }

        // Fetch order details
        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        // Calculate pricing
        const subtotal = order.amount;
        const taxRate = 18; // 18% GST
        const tax = (subtotal * taxRate) / 100;
        const shipping = 0; // Free shipping
        const discount = 0;
        const total = subtotal + tax + shipping - discount;

        // Create invoice
        const invoice = await Invoice.create({
            orderId: order._id,
            orderNumber: order.orderId,
            customer: {
                name: order.customerDetails.name,
                email: order.customerDetails.email,
                mobile: order.customerDetails.mobile,
                address: order.customerDetails.address
            },
            items: order.items || [{
                name: 'Health Monitoring Device',
                quantity: 1,
                price: order.amount,
                total: order.amount
            }],
            pricing: {
                subtotal,
                tax,
                taxRate,
                shipping,
                discount,
                total
            },
            paymentMethod: order.paymentMethod,
            paymentStatus: order.status === 'PAID' || order.status === 'COD_CONFIRMED' ? 'PAID' : 'PENDING',
            status: 'ISSUED'
        });

        // Generate PDF
        const pdfDir = path.join(__dirname, '../../invoices');
        if (!fs.existsSync(pdfDir)) {
            fs.mkdirSync(pdfDir, { recursive: true });
        }

        const pdfPath = path.join(pdfDir, `${invoice.invoiceNumber}.pdf`);
        await generateInvoicePDF(invoice, pdfPath);

        // Update invoice with PDF path
        invoice.pdfPath = pdfPath;
        await invoice.save();

        return res.status(201).json({
            success: true,
            message: 'Invoice generated successfully',
            data: invoice
        });

    } catch (error) {
        console.error('Generate Invoice Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to generate invoice',
            error: error.message
        });
    }
};

/**
 * Get invoice by ID
 * GET /api/invoices/:id
 */
exports.getInvoice = async (req, res) => {
    try {
        const { id } = req.params;

        const invoice = await Invoice.findById(id).populate('orderId');

        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: 'Invoice not found'
            });
        }

        return res.status(200).json({
            success: true,
            data: invoice
        });

    } catch (error) {
        console.error('Get Invoice Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch invoice',
            error: error.message
        });
    }
};

/**
 * Download invoice PDF
 * GET /api/invoices/:id/pdf
 */
exports.downloadInvoicePDF = async (req, res) => {
    try {
        const { id } = req.params;

        const invoice = await Invoice.findById(id);

        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: 'Invoice not found'
            });
        }

        // Check if PDF exists
        if (!invoice.pdfPath || !fs.existsSync(invoice.pdfPath)) {
            // Regenerate PDF
            const pdfDir = path.join(__dirname, '../../invoices');
            if (!fs.existsSync(pdfDir)) {
                fs.mkdirSync(pdfDir, { recursive: true });
            }

            const pdfPath = path.join(pdfDir, `${invoice.invoiceNumber}.pdf`);
            await generateInvoicePDF(invoice, pdfPath);

            invoice.pdfPath = pdfPath;
            await invoice.save();
        }

        // Send PDF file
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=${invoice.invoiceNumber}.pdf`);

        const fileStream = fs.createReadStream(invoice.pdfPath);
        fileStream.pipe(res);

    } catch (error) {
        console.error('Download PDF Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to download invoice',
            error: error.message
        });
    }
};

/**
 * Get all invoices with filters
 * GET /api/invoices
 */
exports.getAllInvoices = async (req, res) => {
    try {
        const {
            page = 1,
            limit = 10,
            status,
            paymentStatus
        } = req.query;

        // Build query
        const query = {};
        if (status) query.status = status;
        if (paymentStatus) query.paymentStatus = paymentStatus;

        // Execute query with pagination
        const skip = (parseInt(page) - 1) * parseInt(limit);
        const invoices = await Invoice.find(query)
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .select('-__v');

        const total = await Invoice.countDocuments(query);

        return res.status(200).json({
            success: true,
            data: invoices,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / parseInt(limit))
            }
        });

    } catch (error) {
        console.error('Get Invoices Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch invoices',
            error: error.message
        });
    }
};

/**
 * Get invoice by order ID
 * GET /api/invoices/order/:orderId
 */
exports.getInvoiceByOrderId = async (req, res) => {
    try {
        const { orderId } = req.params;

        const invoice = await Invoice.findOne({ orderId });

        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: 'Invoice not found for this order'
            });
        }

        return res.status(200).json({
            success: true,
            data: invoice
        });

    } catch (error) {
        console.error('Get Invoice by Order Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch invoice',
            error: error.message
        });
    }
};
