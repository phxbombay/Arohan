const Blog = require('../models/Blog');

/**
 * Create a new blog post
 * POST /api/blog
 */
exports.createPost = async (req, res) => {
    try {
        const {
            title,
            slug,
            content,
            excerpt,
            featuredImage,
            category,
            tags,
            author,
            status,
            publishDate,
            seo
        } = req.body;

        // Validation
        if (!title || !content || !category) {
            return res.status(400).json({
                success: false,
                message: 'Title, content, and category are required'
            });
        }

        // Create blog post
        const blog = await Blog.create({
            title,
            slug: slug || title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            content,
            excerpt,
            featuredImage,
            category,
            tags: tags || [],
            author: author || { name: 'Arohan Team' },
            status: status || 'draft',
            publishDate: publishDate || Date.now(),
            seo
        });

        return res.status(201).json({
            success: true,
            message: 'Blog post created successfully',
            data: blog
        });

    } catch (error) {
        console.error('Create Blog Error:', error);

        // Handle duplicate slug error
        if (error.code === 11000) {
            return res.status(400).json({
                success: false,
                message: 'A blog post with this slug already exists'
            });
        }

        return res.status(500).json({
            success: false,
            message: 'Failed to create blog post',
            error: error.message
        });
    }
};

/**
 * Get all blog posts with filters and pagination
 * GET /api/blog
 */
exports.getAllPosts = async (req, res) => {
    try {
        const {
            page = 1,
            limit = 10,
            category,
            tag,
            status = 'published',
            search
        } = req.query;

        // Build query
        const query = {};

        // Filter by status (default: published)
        if (status) {
            query.status = status;
        }

        // Filter by category
        if (category) {
            query.category = category;
        }

        // Filter by tag
        if (tag) {
            query.tags = tag;
        }

        // Search in title and content
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { content: { $regex: search, $options: 'i' } }
            ];
        }

        // Only show published posts with publishDate <= now for public access
        if (status === 'published') {
            query.publishDate = { $lte: new Date() };
        }

        // Execute query with pagination
        const skip = (parseInt(page) - 1) * parseInt(limit);
        const blogs = await Blog.find(query)
            .sort({ publishDate: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .select('-__v');

        const total = await Blog.countDocuments(query);

        return res.status(200).json({
            success: true,
            data: blogs,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / parseInt(limit))
            }
        });

    } catch (error) {
        console.error('Get Blogs Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch blog posts',
            error: error.message
        });
    }
};

/**
 * Get single blog post by slug
 * GET /api/blog/:slug
 */
exports.getPostBySlug = async (req, res) => {
    try {
        const { slug } = req.params;

        const blog = await Blog.findOne({ slug }).select('-__v');

        if (!blog) {
            return res.status(404).json({
                success: false,
                message: 'Blog post not found'
            });
        }

        // Increment view count
        blog.viewCount += 1;
        await blog.save();

        return res.status(200).json({
            success: true,
            data: blog
        });

    } catch (error) {
        console.error('Get Blog Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch blog post',
            error: error.message
        });
    }
};

/**
 * Update blog post
 * PUT /api/blog/:id
 */
exports.updatePost = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        // Find and update
        const blog = await Blog.findByIdAndUpdate(
            id,
            { $set: updates },
            { new: true, runValidators: true }
        );

        if (!blog) {
            return res.status(404).json({
                success: false,
                message: 'Blog post not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Blog post updated successfully',
            data: blog
        });

    } catch (error) {
        console.error('Update Blog Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to update blog post',
            error: error.message
        });
    }
};

/**
 * Delete blog post
 * DELETE /api/blog/:id
 */
exports.deletePost = async (req, res) => {
    try {
        const { id } = req.params;

        const blog = await Blog.findByIdAndDelete(id);

        if (!blog) {
            return res.status(404).json({
                success: false,
                message: 'Blog post not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Blog post deleted successfully'
        });

    } catch (error) {
        console.error('Delete Blog Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to delete blog post',
            error: error.message
        });
    }
};

/**
 * Get blog categories
 * GET /api/blog/categories
 */
exports.getCategories = async (req, res) => {
    try {
        const categories = await Blog.distinct('category');

        return res.status(200).json({
            success: true,
            data: categories
        });

    } catch (error) {
        console.error('Get Categories Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch categories',
            error: error.message
        });
    }
};
