import logger from '../config/logger.js';
import { auditLog } from '../middleware/auditLog.js';

/**
 * Universal Notification Service
 * Handles multi-channel alerts (SMS, Email, Push)
 * Mocks provider APIs (Twilio/SendGrid) for development
 */
class NotificationService {
    constructor() {
        this.providers = {
            sms: 'Twilio (Mock)',
            email: 'SendGrid (Mock)',
            push: 'Firebase (Mock)'
        };
    }

    /**
     * Send Emergency SMS
     * @param {string} to - Phone number
     * @param {string} message - Text content
     */
    async sendSMS(to, message) {
        try {
            // Validate input
            if (!to || !message) throw new Error('Recipient and message required');

            // Simulate API latency
            await new Promise(resolve => setTimeout(resolve, 300));

            logger.info(`[SMS] Sending to ${to.replace(/^\d{5}/, 'XXXXX')}: ${message}`);

            // Log successful "transmission"
            return {
                status: 'success',
                channel: 'sms',
                provider: this.providers.sms,
                timestamp: new Date().toISOString(),
                messageId: `SMS-${Date.now()}`
            };
        } catch (error) {
            logger.error(`[SMS] Failed to send to ${to}: ${error.message}`);
            return { status: 'failed', error: error.message };
        }
    }

    /**
     * Send Email Notification
     * @param {string} to - Email address
     * @param {string} subject - Subject line
     * @param {string} body - HTML/Text body
     */
    async sendEmail(to, subject, body) {
        try {
            await new Promise(resolve => setTimeout(resolve, 500));

            logger.info(`[EMAIL] Sending to ${to}: ${subject}`);

            return {
                status: 'success',
                channel: 'email',
                provider: this.providers.email,
                timestamp: new Date().toISOString(),
                messageId: `EMAIL-${Date.now()}`
            };
        } catch (error) {
            logger.error(`[EMAIL] Failed to send to ${to}: ${error.message}`);
            return { status: 'failed', error: error.message };
        }
    }

    /**
     * Broadcast Emergency Alert to all channels
     * @param {object} contact - { name, email, phone, relation }
     * @param {object} incident - { type, location, user }
     */
    async broadcastEmergency(contact, incident) {
        const results = [];
        const { user, type, location } = incident;

        const timestamp = new Date().toLocaleTimeString();
        const mapLink = location ? `https://maps.google.com/?q=${location.lat},${location.lng}` : 'Unknown Location';

        // 1. Send SMS (Priority High)
        if (contact.phone) {
            const smsBody = `URGENT: ${user} caused ${type} alert at ${timestamp}. Location: ${mapLink}. Reply STOP if safe.`;
            const smsResult = await this.sendSMS(contact.phone, smsBody);
            results.push(smsResult);
        }

        // 2. Send Email (Priority Medium)
        if (contact.email) {
            const emailBody = `
                <h1>Emergency Alert: ${type}</h1>
                <p><strong>Impacted User:</strong> ${user}</p>
                <p><strong>Time:</strong> ${timestamp}</p>
                <p><strong>Location:</strong> <a href="${mapLink}">View on Map</a></p>
                <p>The Arohan system has detected a critical anomaly.</p>
            `;
            const emailResult = await this.sendEmail(contact.email, `URGENT: Emergency Alert for ${user}`, emailBody);
            results.push(emailResult);
        }

        // 3. Log the broadcast action
        // Note: Actual DB audit log needs userId, handled by controller. This is service-level log.
        logger.info(`Broadcast completed for contact ${contact.name}`, { contactId: contact.contact_id, results });

        return results;
    }
}

export default new NotificationService();
